<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!--<link rel="stylesheet" href="style/foot.css">-->
  <link rel="icon" type="image/x-icon" href="image/Man2pacet-removebg-preview.png">
  <title>Tambah admin</title>
  <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: 'Poppins',sans-serif;
        }
        body{
            background: url('https://man2cianjur.sch.id/media_library/posts/post-image-1676339310951.jpg');
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-size: cover;
            background-position: center;
            overflow: hidden
        }
        .container{
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 90vh;
        }
        .box{
            background-color:rgba(255,255,255,0.5);
            display: flex;
            flex-direction: column;
            padding: 25px 25px;
            border-radius: 20px;
            box-shadow: 0 0 128px 0 rgba(0, 0, 0, 0, 1),
                        0 32px 64px -48px rgba(0, 0, 0, 0,5);
        }
        .form-box{
            width: 450px;
            margin: 0px 10px;
        }
        .form-box header{
            font-size: 25px;
            font-weight: 600;
            padding-bottom: 10px;
            border-bottom: 0px solid #e6e6e6;
            margin-bottom: 10px;
        }
        .form-box form .field{
            display: flex;
            margin-bottom: 10px;
            flex-direction: column;
        }
        .form-box form .input input{
            font-weight: 40px;
            width: 100%;
            font-size: 16px;
            padding: 0 10px;
            border-radius: 1px solid #ccc;
            outline: none;
        }
        .btn{
            height: 35px;
            background: rgba(45, 58, 122, 707);
            border: 0;
            border-radius: 5px;
            color: #fff;
            font-size: 15px;
            cursor: pointer;
            transition: all .3s;
            margin-top: 10px;
            padding: 0px 10px;
        }
        .btn:hover{
            opacity: 0.84;
        }
        .submit{
            width: 100%;
        }
        .links{
            margin-bottom: 15px;
        }

  </style>
</head>
<body>
<div class="form-container">

    <?php
    // Tampilkan pesan sukses jika admin berhasil ditambahkan
    if (isset($success_message)) {
        echo "<p style='color: green;'>$success_message</p>";
    }

    // Tampilkan pesan error jika terjadi kesalahan
    if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
    }
    ?>
 <div class="container">
  <div class="box form-box">
    <header>Tambah admin</header>
      <form method="post" action="">
        <!-- id_admin tidak perlu dimasukkan secara manual, karena diatur sebagai AUTO_INCREMENT -->
        <div class="field input">
          <label for="username">Username:</label>
         <input type="text" name="username" required>
        </div>
        <div class="field input">
          <label for="password">Password:</label>
          <input type="password" name="password" required>
        </div>
        <div class="field">
          <button type="submit"class="btn">Tambah Admin</button>
        </div>
        <div class="links"><a href="1.php">Kembali ke Dashboard</a>
      </div>
      </form>
    </div>
  </div>
</div>

  <script>
    // Get the Sidebar
    var mySidebar = document.getElementById("mySidebar");
    
    // Get the DIV with overlay effect
    var overlayBg = document.getElementById("myOverlay");
    
    // Toggle between showing and hiding the sidebar, and add overlay effect
    function w3_open() {
      if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
        overlayBg.style.display = "none";
      } else {
        mySidebar.style.display = 'block';
        overlayBg.style.display = "block";
      }
    }
    
    // Close the sidebar with the close button
    function w3_close() {
      mySidebar.style.display = "none";
      overlayBg.style.display = "none";
    }
    </script>
</body>
</html>