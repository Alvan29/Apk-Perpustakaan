<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/x-icon" href="image/Man2pacet-removebg-preview.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <title>Who Are You???</title>
    <style>
        .container{
            margin-top: 50px;

        }
        .card{
            background: linear-gradient(to right, rgba(102, 105, 115, 0.5), rgba(161, 161, 164, 0.2))

        }
    </style>
</head>
<body>
    <div class="banner1">
        <img class="img" src="image/1.JPG">
        <div class="text-box text-box1">
                <h1></h1>

                <p></p>
        </div>
    </div>
    <div class="banner2">
        <img class="img" src="image/2.webp">
        <div class="text-box text-box2">
                <h1></h1>
     
                <p></p>
        </div>
    </div>
    <div class="banner3">
        <img class="img" src="image/3.jpg">
        <div class="text-box text-box3">
                <h1></h1>
         
                <p></p>
        </div>
    </div><div class="banner4">
        <img class="img" src="image/4.jpg">
        <div class="text-box text-box4">
                <h1></h1>
              
                <p></p>
        </div>
    </div>
<!-- Content -->
     <div class="container">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                      <img src="image/admin-removebg-preview.png" class="card-img-top" alt="..." style="max-height: 305px;">
                      <h5 class="card-title">Admin</h5>
                      <p class="card-text">Laman untuk login admin</p>
                      <a href="form_login.php"><button type="button" class="btn btn-outline-primary">Login</button></a>
                    </div>
                  </div>
            </div>
            <div class="col">
                <div class="card">
                    <img src="image/siswa2-removebg-preview.png" class="card-img-top" alt="..." style="max-height: 305px;">
                    <div class="card-body">
                      <h5 class="card-title">Siswa</h5>
                      <p class="card-text">Laman untuk absensi siswa</p>
                      <a href="absen_siswa.php"><button type="button" class="btn btn-outline-primary">Absen</button></a>
                    </div>
                  </div>
            </div>
          </div>
      </div>
</body>
</html>