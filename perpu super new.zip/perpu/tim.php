<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style/1.css">
  <link rel="stylesheet" href="style/2.css">
  <link rel="stylesheet" href="style/3.css">
  <link rel="stylesheet" href="style/load.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!--<link rel="stylesheet" href="style/foot.css">-->
  <link rel="icon" type="image/x-icon" href="image/Man2pacet-removebg-preview.png">
  <style>
    html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif;}
    .w3-sidebar {
      z-index: 3;
      width: 250px;
      top: 43px;
      bottom: 0;
      height: inherit;
    }
    html, body{
            margin: 0;
            padding: 0;
            height: 100%
         } 
        #container {
            position:relative;
            left: 200px;
            min-height: 100%;
        }
        h2{
            margin: 10px, 0 , 0, 0;
            padding: 0;
        }
        h3{
            margin: 0;
            padding: 0;
            color: #68676767;
        }
        .card{
            position: relative;
            top: 100px;
            margin: 10px;
            margin-left: 10px;
            width: 300px;
            height: 350px;
            perspective: 1000px;
            cursor: pointer;
        }
        .card img{
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
        }
        .card-container{
            width: 100%;
            height: 100%;
            transform-style: preserve-3d;
            transition: transform 0.5s;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            border-radius: 10px;
        }
        .card:hover .card-container{
            transform: rotateY(180deg);
        }
        .card-face{
            width: 100%;
            height: 100%;
            position: absolute;
            backface-visibility: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            gap: 10px;
            margin: 20px, 0 0 0;
            padding: 20px;
        }
        .front-face{
            transform: rotateY(0deg);
        }
        .back-face{
            transform: rotateY(180deg);
        }
        .row{
            margin: 10px 0 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            padding: 0 20px;
            font-size: 2rem;
        }
        .row i{
            color: #676868;
        }
        .card2{
            position: relative;
            bottom: 260px;
            left: 350px;
            margin: 10px;
            margin-left: 10px;
            width: 300px;
            height: 350px;
            perspective: 1000px;
            cursor: pointer;
        }
        .card2 img{
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
        }
        .card-container2{
            width: 100%;
            height: 100%;
            transform-style: preserve-3d;
            transition: transform 0.5s;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            border-radius: 10px;
        }
        .card2:hover .card-container2{
            transform: rotateY(180deg);
        }
        .card-face2{
            width: 100%;
            height: 100%;
            position: absolute;
            backface-visibility: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            gap: 10px;
            margin: 20px, 0 0 0;
            padding: 20px;
        }
        .front-face2{
            transform: rotateY(0deg);
        }
        .back-face2{
            transform: rotateY(180deg);
        }
        .row2{
            margin: 10px 0 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            padding: 0 20px;
            font-size: 2rem;
        }
        .row2 i{
            color: #676868;
        }
        .ig:hover{
            color: #e1306c;
        }
        .git:hover{
            color: #000000;
        }
        .fb:hover{
            color: #3b5998;
        }
    </style>
  <script src="javascript/main.js"></script>
  <script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 1000);
}

function showPage() {
   document.getElementById("loader").style.display = "none";
   document.getElementById("myDiv").style.display = "block";
}
  </script>
  <title>Tim Kami</title>
</head>
<body>
<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-theme w3-top w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-right w3-hide-large w3-hover-white w3-large w3-theme-l1" href="javascript:void(0)" onclick="w3_open()"><i class="fa fa-bars"></i></a>
    <a href="1.php
    " class="w3-bar-item w3-button w3-theme-l1"><img class="logo" src="image/Man2pacet-removebg-preview.png" alt="icon"></a>
    <a href="1.php
    " class="w3-bar-item w3-button w3-hide-small w3-hover-white">Home</a>
    <a href="tambah_admin.php
    " class="w3-bar-item w3-button w3-hide-small w3-hover-white">Admin</a>
    <a href="pilih-1.php
    " class="w3-bar-item w3-button w3-hide-small w3-hover-white">Log Out</a>
    <a href="tim.php
    " class="w3-bar-item w3-button w3-hide-small w3-hover-white">Contact</a>
    <a href="https://man2cianjur.sch.id/" class="w3-bar-item w3-button w3-hide-small w3-hide-medium w3-hover-white">ABOUT OUR SCHOOL</a>
  </div>
</div>

<div class="card">
    <div class="card-container">
        <div class="card-face front-face">
            <!-- Bagian Depan -->
            <img src="image/a.jpg" alt="">
            <h2>M. Alvan A.G.</h2>
            <h3>Backend Developer</h3>
        </div>
        <div class="card-face back-face">
            <!-- Bagian Belakang -->
            <div class="container-about">
                <h2>About Me:</h2>
                <P>
                    "Selalu berusaha dan senantiasa berdo'a"
                </P>
                <div class="row">
                    <a href="https://wa.me/62959109742295" target="_blank"><i class="bi wa bi-whatsapp"></i></a>
                    <a href="https://www.instagram.com/alvan.5602?igsh=YzljYTk1ODg3Zg==" target="_blank"><i class="bi ig bi-instagram"></i></a>
                    <a href="https://github.com/Alvan29" target="_blank"><i class="bi git bi-github"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card2">
    <div class="card-container2">
        <div class="card-face2 front-face2">
            <!-- Bagian Depan -->
            <img src="image/b.jpg" alt="">
            <h2>M.Marza A</h2>
            <h3>frontend Developer</h3>
        </div>
        <div class="card-face2 back-face2">
            <!-- Bagian Belakang -->
            <div class="container-about2">
                <h2>About Me:</h2>
                <P>
                    "Selalu berusaha dan senantiasa berdo'a"
                </P>
                <div class="row2">
                    <a href="https://discord.com/users/766516723653541909" target="_blank"><i class="bi wa bi-discord"></i></a>
                    <a href="https://www.instagram.com/deonzt_21/" target="_blank"><i class="bi ig bi-instagram"></i></a>
                    <a href="https://github.com/marzaananda" target="_blank"><i class="bi git bi-github"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
  </div>


  <script>
    // Get the Sidebar
    var mySidebar = document.getElementById("mySidebar");
    
    // Get the DIV with overlay effect
    var overlayBg = document.getElementById("myOverlay");
    
    // Toggle between showing and hiding the sidebar, and add overlay effect
    function w3_open() {
      if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
        overlayBg.style.display = "none";
      } else {
        mySidebar.style.display = 'block';
        overlayBg.style.display = "block";
      }
    }
    
    // Close the sidebar with the close button
    function w3_close() {
      mySidebar.style.display = "none";
      overlayBg.style.display = "none";
    }
    </script>
</body>
</html>