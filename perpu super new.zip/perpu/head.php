<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style/1.css">
  <link rel="stylesheet" href="style/2.css">
  <link rel="stylesheet" href="style/3.css">
  <link rel="stylesheet" href="style/load.css">
  <!--<link rel="stylesheet" href="style/foot.css">-->
  <link rel="icon" type="image/x-icon" href="image/Man2pacet-removebg-preview.png">
  <style>
    html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif;}
    .w3-sidebar {
      z-index: 3;
      width: 250px;
      top: 43px;
      bottom: 0;
      height: inherit;
    }
    </style>
  <script src="javascript/main.js"></script>
  <script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 1000);
}

function showPage() {
   document.getElementById("loader").style.display = "none";
   document.getElementById("myDiv").style.display = "block";
}
  </script>
  <title>Home</title>
</head>
<body>
  <div id="loader"></div>
<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-theme w3-top w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-right w3-hide-large w3-hover-white w3-large w3-theme-l1" href="javascript:void(0)" onclick="w3_open()"><i class="fa fa-bars"></i></a>
    <a href="1.php" class="w3-bar-item w3-button w3-theme-l1"><img class="logo" src="image/Man2pacet-removebg-preview.png" alt="icon"></a>
    <a href="head.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Home</a>
    <a href="tambah_admin.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Admin</a>
    <a href="pilih-1.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Log Out</a>
    <a href="tim.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Contact</a>
    <a href="https://man2cianjur.sch.id/" class="w3-bar-item w3-button w3-hide-small w3-hide-medium w3-hover-white">ABOUT OUR SCHOOL</a>
  </div>
</div>

<!-- Sidebar -->
<nav class="w3-sidebar w3-bar-block w3-collapse w3-large w3-theme-l5 w3-animate-left" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-right w3-xlarge w3-padding-large w3-hover-black w3-hide-large" title="Close Menu">
    <i class="fa fa-remove"></i>
  </a>
  <h4 class="w3-bar-item"><b>Menu</b></h4>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_absen.php">Absen</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_buku.php">Data Buku</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_kategori.php">Kategori</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_siswa.php">Data Siswa</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="peminjaman.php">Peminjaman Buku</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_peminjaman.php">Data Peminjaman</a>
</nav>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
  </div>


  <script>
    // Get the Sidebar
    var mySidebar = document.getElementById("mySidebar");
    
    // Get the DIV with overlay effect
    var overlayBg = document.getElementById("myOverlay");
    
    // Toggle between showing and hiding the sidebar, and add overlay effect
    function w3_open() {
      if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
        overlayBg.style.display = "none";
      } else {
        mySidebar.style.display = 'block';
        overlayBg.style.display = "block";
      }
    }
    
    // Close the sidebar with the close button
    function w3_close() {
      mySidebar.style.display = "none";
      overlayBg.style.display = "none";
    }
    </script>
</body>
</html>