<?php
session_start();

// Include file koneksi.php untuk menghubungkan ke database
include "koneksi.php";

// Proses login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil nilai input dari formulir login
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mencari admin berdasarkan username dan password
    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE username = '$username' AND password = '$password'");
    $admin = mysqli_fetch_assoc($query);

    // Jika admin ditemukan
    if ($admin) {
        // Set session admin_id
        $_SESSION['admin_id'] = $admin['Id_admin'];

        // Redirect ke halaman admin_dashboard.php
        header("Location: 1.php");
        exit();
    } else {
        // Jika login gagal, tampilkan pesan error
        $error_message = "Username atau Password salah.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: 'Poppins',sans-serif;
        }
        body{
            background: url('https://man2cianjur.sch.id/media_library/posts/post-image-1676339310951.jpg');
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-size: cover;
            background-position: center;
            overflow: hidden
        }
        .container{
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 90vh;
        }
        .box{
            background-color:rgba(255,255,255,0.5);
            display: flex;
            flex-direction: column;
            padding: 25px 25px;
            border-radius: 20px;
            box-shadow: 0 0 128px 0 rgba(0, 0, 0, 0, 1),
                        0 32px 64px -48px rgba(0, 0, 0, 0,5);
        }
        .form-box{
            width: 450px;
            margin: 0px 10px;
        }
        .form-box header{
            font-size: 25px;
            font-weight: 600;
            padding-bottom: 10px;
            border-bottom: 0px solid #e6e6e6;
            margin-bottom: 10px;
        }
        .form-box form .field{
            display: flex;
            margin-bottom: 10px;
            flex-direction: column;
        }
        .form-box form .input input{
            font-weight: 40px;
            width: 100%;
            font-size: 16px;
            padding: 0 10px;
            border-radius: 1px solid #ccc;
            outline: none;
        }
        .btn{
            height: 35px;
            background: rgba(45, 58, 122, 707);
            border: 0;
            border-radius: 5px;
            color: #fff;
            font-size: 15px;
            cursor: pointer;
            transition: all .3s;
            margin-top: 10px;
            padding: 0px 10px;
        }
        .btn:hover{
            opacity: 0.84;
        }
        .submit{
            width: 100%;
        }
        .links{
            margin-bottom: 15px;
        }

</style>

    </style>
</head>

<body>
    <div class="container">
        <div class="box form-box">
            <header>Login as admin</header>

            <form method="post" action="">
                 <div class="field input">
                     
                     <label for="username">Username:</label>
                     <input type="text" id="username" name="username" required>
                </div>
                <div class="field input">    
                     <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>    

                </div>
                <div class="field">  
                     <button type="submit" class="btn">Login</button>
                </div>
              <div class="links">tidak punya akun? <a href="tambah_admin.php">buat admin baru</a></div>
            </form>
        </div>
    </div>

</body>


</html>
