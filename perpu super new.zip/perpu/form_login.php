<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/x-icon" href="image/Man2pacet-removebg-preview.png">

</head>
<body>
    <div class="banner1">
        <img class="img" src="image/1.JPG">
        <div class="text-box text-box1">
                <h1>Selamat Datang Di perpustakaann MAN 2 CIANJUR</h1>
                <span></span>
                <p>Selamat datang di perpustakaan kami yang penuh dengan pengetahuan dan inspirasi! Saya sangat senang melihat Anda hadir di sini untuk menjelajahi dunia buku dan ilmu pengetahuan. Perpustakaan merupakan tempat yang sangat istimewa, tempat di mana kita dapat mengembangkan diri melalui pembelajaran dan pemahaman.</p>
        </div>
    </div>
    <div class="banner2">
        <img class="img" src="image/2.webp">
        <div class="text-box text-box2">
                <h1>Selamat Datang Di perpustakaann MAN 2 CIANJUR</h1>
                <span></span>
                <p>Perpustakaan kami bukan hanya tempat untuk membaca, tetapi juga tempat untuk memimpikan, mencipta, dan terhubung dengan berbagai ide dan cerita. Saya harap kunjungan Anda di sini hari ini membawa Anda ke dalam petualangan yang penuh makna dan pengalaman yang mendalam.</p>
        </div>
    </div>
    <div class="banner3">
        <img class="img" src="image/3.jpg">
        <div class="text-box text-box3">
                <h1>Selamat Datang Di perpustakaann MAN 2 CIANJUR</h1>
                <span></span>
                <p>Mari bersama-sama merayakan keajaiban dunia literasi yang tak terbatas. Mari menjadikan perpustakaan ini sebagai tempat yang memperkaya jiwa dan membawa inspirasi bagi setiap langkah kita.</p>
        </div>
    </div><div class="banner4">
        <img class="img" src="image/4.jpg">
        <div class="text-box text-box4">
                <h1>Selamat Datang Di perpustakaann MAN 2 CIANJUR</h1>
                <span></span>
                <p>
                 Sekali lagi, selamat datang di perpustakaan kami. Terima kasih atas kehadiran Anda. Semoga kunjungan Anda hari ini memberikan pengalaman yang memuaskan dan berharga.
                    
                Salam literasi,</p>
        </div>
    </div>

    <header>
        <h2 class="logo"></h2>
        <na class="navigation">
            <a href="absen_siswa.php">Absen siswa</a>
            <a href="login_admin.php">Login Admin</a>
            <!--<button class="btnlogin-popup"><a href="login_admin.php">login</a></button>-->
        </nav>
    </header>

    <div class="wrapper">
        <span class="icon-close">
            <ion-icon name="close"></ion-icon>
        </span>

    <script src="script.js"></script>
    <script src="script.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>
