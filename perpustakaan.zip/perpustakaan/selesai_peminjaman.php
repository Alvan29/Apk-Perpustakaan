<?php
include "koneksi.php";

// Ambil id peminjaman dari URL
$Id_peminjaman = $_GET['Id_peminjaman'];

// Update status_pinjam menjadi 'Kembali' untuk menandakan selesai peminjaman
$query_selesai_peminjaman = mysqli_query($koneksi, "UPDATE peminjaman SET status_pinjam = 'Kembali' WHERE Id_peminjaman = '$Id_peminjaman'");

if (!$query_selesai_peminjaman) {
    die("Query to update status peminjaman failed: " . mysqli_error($koneksi));
}

// Redirect kembali ke halaman peminjaman setelah berhasil
header('Location: peminjaman.php');
exit;
?>
