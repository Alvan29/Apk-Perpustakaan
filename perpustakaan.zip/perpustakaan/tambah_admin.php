<?php
session_start();

// Include file koneksi.php untuk menghubungkan ke database
include "koneksi.php";

// Cek apakah admin sudah login, jika tidak, redirect ke halaman login
if (!isset($_SESSION['admin_id'])) {
   header("Location: index.php");
   exit();
}

// Proses tambah admin
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil nilai input dari formulir tambah admin
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk menambah admin baru ke dalam database
    $query_tambah_admin = mysqli_query($koneksi, "INSERT INTO admin (username, password) VALUES ('$username', '$password')");

    if ($query_tambah_admin) {
        // Jika berhasil menambahkan admin, tampilkan pesan sukses
        $success_message = "Admin berhasil ditambahkan.";
    } else {
        // Jika terjadi kesalahan, tampilkan pesan error
        $error_message = "Gagal menambahkan admin. Silakan coba lagi.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }

        .form-container h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .form-container form {
            display: flex;
            flex-direction: column;
        }

        .form-container label {
            margin-bottom: 8px;
            color: #555;
            font-weight: bold;
        }

        .form-container input {
            padding: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-container button {
            padding: 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #218838;
        }

        .back-link {
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="form-container">
        <h2>Tambah Admin</h2>

        <?php
        // Tampilkan pesan sukses jika admin berhasil ditambahkan
        if (isset($success_message)) {
            echo "<p style='color: green;'>$success_message</p>";
        }

        // Tampilkan pesan error jika terjadi kesalahan
        if (isset($error_message)) {
            echo "<p style='color: red;'>$error_message</p>";
        }
        ?>

        <form method="post" action="">
            <!-- id_admin tidak perlu dimasukkan secara manual, karena diatur sebagai AUTO_INCREMENT -->
            <label for="username">Username:</label>
            <input type="text" name="username" required>

            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <button type="submit">Tambah Admin</button>
        </form>

        <a href="Home.php" class="back-link">Kembali ke Dashboard</a>
    </div>
</body>

</html>

