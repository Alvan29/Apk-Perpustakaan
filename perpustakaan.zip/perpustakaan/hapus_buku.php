<?php
include "koneksi.php";

// Periksa apakah parameter id_buku telah diberikan
if (!isset($_GET['id'])) {
    header('Location: data_buku.php');
    exit;
}

$id_buku = $_GET['id'];

// Query untuk mendapatkan data buku berdasarkan id
$query = mysqli_query($koneksi, "SELECT * FROM buku WHERE id_buku = '$id_buku'");
$buku = mysqli_fetch_assoc($query);

// Periksa apakah buku dengan id yang diberikan ditemukan
if (!$buku) {
    header('Location: data_buku.php');
    exit;
}

// Proses penghapusan buku jika dikonfirmasi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Hapus data buku dari database
    $delete_query = mysqli_query($koneksi, "DELETE FROM buku WHERE id_buku = '$id_buku'");

    if ($delete_query) {
        // Redirect kembali ke halaman data buku setelah berhasil menghapus
        header('Location: data_buku.php');
        exit;
    } else {
        // Tampilkan pesan kesalahan jika gagal menghapus
        $error_message = "Gagal menghapus buku.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Buku</title>
    <!-- Tautan ke CSS atau Bootstrap jika digunakan -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Bagian header (jika ada) -->
    <?php include "header.html"; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Hapus Buku</div>
                    <div class="card-body">
                        <!-- Konfirmasi Penghapusan Buku -->
                        <p>Apakah Anda yakin ingin menghapus buku dengan judul "<?php echo $buku['judul']; ?>"?</p>

                        <!-- Formulir Konfirmasi -->
                        <form method="POST" action="">
                            <!-- Tombol untuk mengkonfirmasi penghapusan -->
                            <input type="submit" class="btn btn-danger" name="hapus_buku" value="Ya, Hapus">
                            <!-- Tautan untuk membatalkan penghapusan -->
                            <a href="data_buku.php" class="btn btn-secondary">Batal</a>
                        </form>

                        <!-- Tampilkan pesan kesalahan jika ada -->
                        <?php if (isset($error_message)) : ?>
                            <p style="color: red;"><?php echo $error_message; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bagian footer (jika ada) -->
    <?php include "footer.html"; ?>
</body>
</html>
