<?php
include "koneksi.php";

if (isset($_GET['Id_buku'])) {
    $kodeBuku = $_GET['Id_buku'];

    // Query untuk mengambil informasi judul dan penulis berdasarkan kode buku
    $query_info_buku = mysqli_query($koneksi, "SELECT judul, nama_penulis FROM buku WHERE Id_buku = '$kodeBuku'");
    
    if (!$query_info_buku) {
        die("Query to retrieve book information failed: " . mysqli_error($koneksi));
    }

    $info_buku = mysqli_fetch_assoc($query_info_buku);

    // Mengirim data sebagai JSON
    header('Content-Type: application/json');
    echo json_encode($info_buku);
}
?>
