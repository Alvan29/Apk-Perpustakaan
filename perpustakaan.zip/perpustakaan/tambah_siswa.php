<?php
include "koneksi.php";

// Proses formulir tambah jika formulir dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari formulir
    $nis = $_POST['nis'];
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];

    // Upload foto siswa
    $foto_siswa = $_FILES['foto_siswa']['name'];
    $temp = $_FILES['foto_siswa']['tmp_name'];
    $folder = "uploads/";

    // Pindahkan file ke folder uploads
    move_uploaded_file($temp, $folder . $foto_siswa);

    // Insert data siswa ke database
    $insert_query = mysqli_query($koneksi, "INSERT INTO siswa (NIS, Nama_Siswa, Jenis_Kelamin, Tempat_Lahir, Tanggal_Lahir, Alamat, No_Telepon, Foto_Siswa, kelas) VALUES ('$nis', '$nama_siswa', '$jenis_kelamin', '$tempat_lahir', '$tanggal_lahir', '$alamat', '$no_telepon', '$foto_siswa', '$kelas')");

    if ($insert_query) {
        // Redirect kembali ke halaman data siswa setelah berhasil menambahkan
        header('Location: data_siswa.php');
        exit;
    } else {
        // Tampilkan pesan kesalahan jika gagal menambahkan
        $error_message = "Gagal menambahkan siswa.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Siswa</title>
    <!-- Tautan ke CSS atau Bootstrap jika digunakan -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Bagian header (jika ada) -->
    <?php include "header.html"; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Tambah Siswa</div>
                    <div class="card-body">
                        <!-- Formulir Tambah Siswa -->
                        <form method="POST" action="" enctype="multipart/form-data">
                            <!-- Input nilai-nilai siswa yang bisa diisi -->
                            <div class="form-group">
                                <label for="nis">NIS:</label>
                                <input type="text" class="form-control" name="nis" required>
                            </div>

                            <div class="form-group">
                                <label for="nama_siswa">Nama Siswa:</label>
                                <input type="text" class="form-control" name="nama_siswa" required>
                            </div>

                            <div class="form-group">
                                <label for="kelas">Kelas:</label>
                                <input type="text" class="form-control" id="kelas" name="kelas" required>
                            </div>

                            <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin:</label>
                                <select class="form-control" name="jenis_kelamin" required>
                                    <option value="Laki-laki">Laki-laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="tempat_lahir">Tempat Lahir:</label>
                                <input type="text" class="form-control" name="tempat_lahir" required>
                            </div>

                            <div class="form-group">
                                <label for="tanggal_lahir">Tanggal Lahir:</label>
                                <input type="date" class="form-control" name="tanggal_lahir" required>
                            </div>

                            <div class="form-group">
                                <label for="alamat">Alamat:</label>
                                <textarea class="form-control" name="alamat" required></textarea>
                            </div>

                            <div class="form-group">
                                <label for="no_telepon">No. Telepon:</label>
                                <input type="text" class="form-control" name="no_telepon" required>
                            </div>

                            <div class="form-group">
                                <label for="foto_siswa">Foto Siswa:</label>
                                <input type="file" class="form-control" name="foto_siswa" accept="image/*" required>
                            </div>

                            <!-- Tombol untuk mengirim formulir -->
                            <input type="submit" class="btn btn-primary" name="tambah_siswa" value="Tambah Siswa">
                        </form>

                        <!-- Tampilkan pesan kesalahan jika ada -->
                        <?php if (isset($error_message)) : ?>
                            <p style="color: red;"><?php echo $error_message; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bagian footer (jika ada) -->
    <?php include "footer.html"; ?>
</body>
</html>
