<?php
include "koneksi.php";

// Query untuk mendapatkan data siswa
$query_siswa = mysqli_query($koneksi, "SELECT * FROM siswa");
if (!$query_siswa) {
    die("Query to retrieve siswa failed: " . mysqli_error($koneksi));
}

// Query untuk mendapatkan data buku
$query_buku = mysqli_query($koneksi, "SELECT * FROM buku");
if (!$query_buku) {
    die("Query to retrieve buku failed: " . mysqli_error($koneksi));
}

// Proses formulir peminjaman jika formulir dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari formulir
    $Id_peminjaman = $_POST['Id_peminjaman']; 
    $nis = $_POST['nis'];
    $Id_buku = $_POST['Id_buku']; 
    $tanggal_pinjam = $_POST['tanggal_pinjam'];
    $batas_pinjam = $_POST['batas_pinjam'];
    $jumlah_pinjam = $_POST['jumlah_pinjam'];
    $status_pinjam = $_POST['status_pinjam'];

    // Query untuk menyimpan data peminjaman ke database
    $query_peminjaman = mysqli_query($koneksi, "INSERT INTO peminjaman (Id_peminjaman, nis, Id_buku, tanggal_pinjam, batas_pinjam, jumlah_pinjam, status_pinjam) VALUES ('$Id_peminjaman', '$nis', '$Id_buku', '$tanggal_pinjam', '$batas_pinjam', '$jumlah_pinjam', '$status_pinjam')");
    
    if (!$query_peminjaman) {
        die("Query to insert peminjaman failed: " . mysqli_error($koneksi));
    }

    // Jika berhasil disimpan, kurangi jumlah buku yang tersedia
    $query_update_buku = mysqli_query($koneksi, "UPDATE buku SET jumlah = jumlah - '$jumlah_pinjam' WHERE Id_buku = '$Id_buku'");
    
    if (!$query_update_buku) {
        die("Query to update buku failed: " . mysqli_error($koneksi));
    }

    // Redirect kembali ke halaman peminjaman setelah berhasil
    header('Location: peminjaman.php');
    exit;
}
?>

<!-- ... (kode HTML selanjutnya tetap sama) ... -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Buku</title>
    <!-- Tautan ke CSS atau Bootstrap jika digunakan -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Bagian header (jika ada) -->
    <?php include "header.html"; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Peminjaman Buku</div>
                    <div class="card-body">
                    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Peminjaman Buku</div>
                    <div class="card-body">
                        <!-- Formulir Peminjaman Buku -->
                        <form method="POST" action="" id="form-peminjaman">
                            <div class="form-group">
                                <label for="nis">Nama Siswa:</label>
                                <select class="form-control" id="nis" name="nis" required>
                                    <?php
                                        while ($siswa = mysqli_fetch_assoc($query_siswa)) : ?>
                                            <option value="<?php echo $siswa['nis']; ?>"><?php echo $siswa['nama_siswa']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="Id_buku">Kode Buku:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="Id_buku" name="Id_buku" placeholder="Kode Buku" required>
                            <div class="input-group-append">
                                <button type="button" class="btn btn-primary" id="btn-ok">OK</button></div>
                            </div>
                            </div>
                            <div class="form-group">
                                <label for="judul">Judul Buku:</label>
                                <input type="text" class="form-control" id="judul" name="judul" readonly>
                            </div>
                            <div class="form-group">
                                <label for="nama_penulis">Penulis Buku:</label>
                                <input type="text" class="form-control" id="nama_penulis" name="nama_penulis" readonly>
                            </div>
                            <div class="form-group">
                                <label for="tanggal_pinjam">Tanggal Pinjam:</label>
                                <input type="date" class="form-control" id="tanggal_pinjam" name="tanggal_pinjam" required>
                            </div>
                            <div class="form-group">
                                <label for="batas_pinjam">Batas Pinjam:</label>
                                <input type="date" class="form-control" id="batas_pinjam" name="batas_pinjam" required>
                            </div>
                            <div class="form-group">
                                <label for="jumlah_pinjam">Jumlah Buku yang Dipinjam:</label>
                                <input type="number" class="form-control" id="jumlah_pinjam" name="jumlah_pinjam" min="1" required>
                            </div>
                            <div class="form-group">
                                <label for="status_pinjam">Status Pinjam:</label>
                                <select class="form-control" id="status_pinjam" name="status_pinjam" required>
                                <option value="Pinjam">Pinjam</option>
                                <option value="Kembali">Kembali</option>
                                </select>
                            </div>

                            <!-- Tombol untuk mengirim formulir -->
                            <input type="submit" class="btn btn-primary" name="pinjam_buku" value="Pinjam Buku">
                        </form>

<!-- Script JavaScript untuk melakukan AJAX -->
<script>
    document.getElementById("btn-ok").addEventListener("click", function () {
        // Mengambil nilai kode buku dari input
        var kodeBuku = document.getElementById("Id_buku").value;

        // Melakukan permintaan AJAX ke ambil_info_buku.php dengan menggunakan kode buku
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                // Parsing data JSON yang diterima
                var data = JSON.parse(this.responseText);

                // Mengisi nilai judul buku dan penulis pada formulir
                document.getElementById("judul").value = data.judul;
                document.getElementById("nama_penulis").value = data.nama_penulis;
            }
        };
        xhr.open("GET", "ambil_info_buku.php?Id_buku=" + kodeBuku, true);
        xhr.send();
    });
</script>

                        <!-- Tampilkan pesan kesalahan jika ada -->
                        <?php if (isset($error_message)) : ?>
                            <p style="color: red;"><?php echo $error_message; ?></p>
                        <?php endif; ?>

<!-- Bagian footer (jika ada) -->
<?php include "footer.html"; ?>

</body>
</html>