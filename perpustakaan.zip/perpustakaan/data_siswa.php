<?php
include "proteksi.php";

// Query untuk mendapatkan daftar kelas
$query_kelas = mysqli_query($koneksi, "SELECT DISTINCT kelas FROM siswa");

// Periksa apakah ada parameter kelas yang dipilih
$selected_kelas = isset($_GET['kelas']) ? $_GET['kelas'] : '';

// Query untuk mendapatkan data siswa berdasarkan kelas yang dipilih
$query = mysqli_query($koneksi, "SELECT * FROM siswa" . ($selected_kelas ? " WHERE kelas='$selected_kelas'" : ""));

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Data Siswa</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <form method="GET" action="">
                                    <div class="form-group">
                                        <label for="kelas">Pilih Kelas:</label>
                                        <select name="kelas" id="kelas" class="form-control" onchange="this.form.submit()">
                                            <option value="" <?php echo (!$selected_kelas ? 'selected' : ''); ?>>Semua Kelas</option>
                                            <?php while ($row_kelas = mysqli_fetch_assoc($query_kelas)) : ?>
                                                <option value="<?php echo $row_kelas['kelas']; ?>" <?php echo ($selected_kelas == $row_kelas['kelas'] ? 'selected' : ''); ?>><?php echo $row_kelas['kelas']; ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col">
                                <table class="table table-bordered table-striped">
                                    <tr>
                                        <th>No</th>
                                        <th>NIS</th>
                                        <th>Nama Siswa</th>
                                        <th>Kelas</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Tempat Lahir</th>
                                        <th>Tanggal Lahir</th>
                                        <th>Alamat</th>
                                        <th>No. Telepon</th>
                                        <th>Foto Siswa</th>
                                        <th>Aksi</th>
                                    </tr>
                                    <?php
                                    $no = 1;
                                    while ($siswa = mysqli_fetch_assoc($query)) :
                                    ?>
                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $siswa['nis']; ?></td>
                                            <td><?php echo $siswa['nama_siswa']; ?></td>
                                            <td><?php echo $siswa['kelas'] ?></td>
                                            <td><?php echo $siswa['jenis_kelamin']; ?></td>
                                            <td><?php echo $siswa['tempat_lahir']; ?></td>
                                            <td><?php echo $siswa['tanggal_lahir']; ?></td>
                                            <td><?php echo $siswa['alamat']; ?></td>
                                            <td><?php echo $siswa['no_telepon']; ?></td>
                                            <td>
                                                <?php if (!empty($siswa['foto_siswa'])) : ?>
                                                    <img src="uploads/<?php echo $siswa['foto_siswa']; ?>" alt="Foto Siswa" style="max-width: 100px;">
                                                <?php else : ?>
                                                    Tidak Ada Foto
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <!-- Tautan untuk mengedit dan menghapus siswa -->
                                                <a href="edit_siswa.php?NIS=<?php echo $siswa['nis']; ?>" class="btn btn-warning">Edit</a>
                                                <a href="hapus_siswa.php?NIS=<?php echo $siswa['nis']; ?>" class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include "footer.html"; ?>

</body>

</html>
