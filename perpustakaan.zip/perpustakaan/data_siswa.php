<?php
include "koneksi.php";

// Query untuk mendapatkan data siswa
$query = mysqli_query($koneksi, "SELECT * FROM siswa");

// Periksa jika ada parameter pencarian
$keyword = "";
if (isset($_GET['cari'])) {
    $keyword = $_GET['keyword'];
    $query = mysqli_query($koneksi, "SELECT * FROM siswa WHERE NIS LIKE '%$keyword%' OR Nama_Siswa LIKE '%$keyword%'");
}

?>

<style>
    @media print {
        .no-print, .form-control {
            display: none;
        }
    }
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa</title>
    <!-- Tautan ke CSS atau Bootstrap jika digunakan -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Bagian header (jika ada) -->
    <?php include "header.html"; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Data Siswa</div>
                    <div class="card-body">
                        <div class="row">
                        <div class="col">
                                <a href="tambah_siswa.php" class="btn btn-primary">Tambah Data</a>
                            </div>
                            <div class="col">
                                <form class="form-inline float-right" method="GET">
                                    <input type="text" class="form-control" name="keyword" placeholder="Cari berdasarkan NIS atau Nama Siswa" value="<?php echo $keyword; ?>">
                                    <input type="submit" class="btn btn-primary ml-2" name="cari" value="Cari">
                                </form>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col">
                                <table class="table table-bordered table-striped">
                                    <tr>
                                        <th>No</th>
                                        <th>NIS</th>
                                        <th>Nama Siswa</th>
                                        <th>Kelas</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Tempat Lahir</th>
                                        <th>Tanggal Lahir</th>
                                        <th>Alamat</th>
                                        <th>No. Telepon</th>
                                        <th>Foto Siswa</th>
                                        <th class="no-print">Aksi</th>
                                    </tr>
                                    <?php
                                    $no = 1;
                                    while ($siswa = mysqli_fetch_assoc($query)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $siswa['nis']; ?></td>
                                            <td><?php echo $siswa['nama_siswa']; ?></td>
                                            <td><?php echo $siswa['kelas'] ?></td>
                                            <td><?php echo $siswa['jenis_kelamin']; ?></td>
                                            <td><?php echo $siswa['tempat_lahir']; ?></td>
                                            <td><?php echo $siswa['tanggal_lahir']; ?></td>
                                            <td><?php echo $siswa['alamat']; ?></td>
                                            <td><?php echo $siswa['no_telepon']; ?></td>
                                            <td>
                                                <?php if (!empty($siswa['foto_siswa'])) : ?>
                                                    <img src="uploads/<?php echo $siswa['foto_siswa']; ?>" alt="Foto Siswa" style= "max-width: 100px;" >
                                                <?php else : ?>
                                                    Tidak Ada Foto
                                                <?php endif; ?>
                                            </td>
                                            <td class="no-print">
                                                <!-- Tautan untuk mengedit dan menghapus siswa -->
                                                <a href="edit_siswa.php?NIS=<?php echo $siswa['nis']; ?>" class="btn btn-warning">Edit</a>
                                                <a href="hapus_siswa.php?NIS=<?php echo $siswa['nis']; ?>" class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bagian footer (jika ada) -->
    <?php include "footer.html"; ?>
</body>
</html>
