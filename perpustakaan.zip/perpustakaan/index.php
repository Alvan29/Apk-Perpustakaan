<?php include "koneksi.php"; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <title>Login</title>
    <style>
        .card{
            margin-top: 40px;
        }
    </style>
</head>
<body>
      <!-- Content -->
      <div class="container">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                      <img src="img/admin.png" class="card-img-top" alt="..." style="max-height: 305px;">
                      <h5 class="card-title">Admin</h5>
                      <p class="card-text">Laman untuk login admin</p>
                      <a href="login_admin.php"><button type="button" class="btn btn-outline-primary">Login</button></a>
                    </div>
                  </div>
            </div>
            <div class="col">
                <div class="card">
                    <img src="img/siswa.jpg" class="card-img-top" alt="..." style="max-height: 305px;">
                    <div class="card-body">
                      <h5 class="card-title">Siswa</h5>
                      <p class="card-text">Laman untuk absensi siswa</p>
                      <a href="absen_siswa.php"><button type="button" class="btn btn-outline-primary">Absen</button></a>
                    </div>
                  </div>
            </div>
          </div>
      </div>
</body>
</html>