<?php 
session_start();
include "koneksi.php"; include "header.html";

// Periksa jika pengguna belum login, jika ya, redirect ke halaman login
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}
?>