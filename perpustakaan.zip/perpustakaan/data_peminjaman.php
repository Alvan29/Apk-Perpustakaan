<?php
include "header.html";
include "koneksi.php";
?>

<style>
    @media print {
        .form-inline {
            display: none;
        }
    }
</style>

<div class="container">
    <div class="row">
        <div class="col-lg-12 mt-2" style="min-height: 800px;">
            <div class="card">
                <div class="card-header">Daftar Peminjaman</div>
                <div class="card-body">
                    <div class="row mt-3">
                        <div class="col">
                            <form method="GET" action="data_peminjaman.php" class="form-inline">
                                <input type="date" name="tgl_mulai" class="form-control mr-3"> -
                                <input type="date" name="tgl_selesai" class="form-control ml-3">
                                <button type="submit" class="btn btn-primary ml-3" value="cari">Cek</button>
                            </form>
                        </div>
                        <div class="col mt-3">
                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th>No</th>
                                    <th>ID Peminjaman</th>
                                    <th>NIS</th>
                                    <th>Nama</th>
                                    <th>Kelas</th>
                                    <th>Judul Buku</th>
                                    <th>Tanggal Pinjam</th>
                                    <th>Batas Pinjam</th>
                                    <th>Jumlah Buku</th>
                                    <th>Status Pinjam</th>
                                    <th>Aksi</th>
                                </tr>
                                <?php
                                $tgl_mulai = isset($_GET['tgl_mulai']) ? $_GET['tgl_mulai'] : '';
                                $tgl_selesai = isset($_GET['tgl_selesai']) ? $_GET['tgl_selesai'] : '';

                                $where_clause = "";
                                if (!empty($tgl_mulai) && !empty($tgl_selesai)) {
                                    // Jika rentang waktu dimasukkan
                                    $where_clause = "WHERE peminjaman.tanggal_pinjam BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
                                }

                                $query_peminjaman = mysqli_query($koneksi, "SELECT peminjaman.Id_peminjaman, siswa.nis, siswa.nama_siswa AS siswa_nama, siswa.kelas, buku.judul, peminjaman.tanggal_pinjam, peminjaman.batas_pinjam, peminjaman.jumlah_pinjam, peminjaman.status_pinjam FROM peminjaman JOIN siswa ON peminjaman.nis = siswa.nis JOIN buku ON peminjaman.Id_buku = buku.Id_buku $where_clause");

                                $num_rows = mysqli_num_rows($query_peminjaman);
                                if ($num_rows < 1) {
                                    // Tidak ada data, tampilkan pesan
                                    echo '<div class="col mt-3">Tidak ada data</div>';
                                } else {
                                    $no = 1;
                                    while ($data_peminjaman = mysqli_fetch_assoc($query_peminjaman)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $data_peminjaman['Id_peminjaman']; ?></td>
                                            <td><?php echo $data_peminjaman['nis']; ?></td>
                                            <td><?php echo $data_peminjaman['siswa_nama']; ?></td>
                                            <td><?php echo $data_peminjaman['kelas']; ?></td>
                                            <td><?php echo $data_peminjaman['judul']; ?></td>
                                            <td><?php echo $data_peminjaman['tanggal_pinjam']; ?></td>
                                            <td><?php echo $data_peminjaman['batas_pinjam']; ?></td>
                                            <td><?php echo $data_peminjaman['jumlah_pinjam']; ?></td>
                                            <td><?php echo $data_peminjaman['status_pinjam']; ?></td>
                                            <td>
                                                <?php
                                                if ($data_peminjaman['status_pinjam'] == 'Pinjam') {
                                                    echo '<a href="selesai_peminjaman.php?Id_peminjaman=' . $data_peminjaman['Id_peminjaman'] . '" class="btn btn-success">Selesai</a>';
                                                } else {
                                                    echo 'Peminjaman Selesai';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                <?php
                                    }
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "footer.html";
?>
