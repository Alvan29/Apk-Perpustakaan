<?php
include "header.html";
include "koneksi.php";

// Proses formulir tambah jika formulir dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari formulir
    $Id_buku = $_POST['Id_buku'];
    $judul = $_POST['judul'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $nama_penulis = $_POST['nama_penulis'];
    $penerbit = $_POST['penerbit'];
    $jumlah = $_POST['jumlah'];
    $Id_kategori = $_POST['Id_kategori'];

    // Upload foto buku
    $foto_sampul = $_FILES['foto_sampul']['name'];
    $temp = $_FILES['foto_sampul']['tmp_name'];
    $folder = "uploads/";

    // Pindahkan file ke folder uploads
    move_uploaded_file($temp, $folder . $foto_sampul);

    // Insert data buku ke database
    $insert_query = mysqli_query($koneksi, "INSERT INTO buku (Id_buku, judul, tahun_terbit, jumlah, foto_sampul, penerbit, nama_penulis, Id_kategori) VALUES ('$Id_buku', '$judul', '$tahun_terbit', '$jumlah', '$foto_sampul', '$penerbit', '$nama_penulis', '$Id_kategori')");

    if ($insert_query) {
        // Redirect kembali ke halaman data buku setelah berhasil menambahkan
        header('Location: data_buku.php');
        exit;
    } else {
        // Tampilkan pesan kesalahan jika gagal menambahkan
        $error_message = "Gagal menambahkan buku.";
    }
}
?>


<div class="container">
    <div class="row">
        <div class="col-lg-12 mt-2">
            <div class="card">
                <div class="card-header">Tambah Data Buku</div>
                <div class="card-body">
                    <form action="simpan_data_buku.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="Id_buku">Kode Buku:</label>
                            <input type="text" class="form-control" id="Id_buku" name="Id_buku" placeholder="ISBN Buku" required>
                        </div>
                        <div class="form-group">
                            <label for="judul">Judul Buku:</label>
                            <input type="text" class="form-control" id="judul" name="judul" required>
                        </div>
                        <div class="form-group">
                            <label for="Id_kategori">Kategori:</label>
                            <select class="form-control" id="Id_kategori" name="Id_kategori" required>
                                <?php
                                // Ambil data kategori dari database
                                $query_kategori = mysqli_query($koneksi, "SELECT * FROM kategori");
                                while ($row_kategori = mysqli_fetch_assoc($query_kategori)) {
                                    echo "<option value='" . $row_kategori['Id_kategori'] . "'>" . $row_kategori['nama_kategori'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="tahun_terbit">Tahun Terbit:</label>
                            <input type="text" class="form-control" id="tahun_terbit" name="tahun_terbit" required>
                        </div>
                        <div class="form-group">
                            <label for="nama_penulis">Penulis:</label>
                            <input type="text" class="form-control" id="nama_penulis" name="nama_penulis" required>
                        </div>
                        <div class="form-group">
                            <label for="penerbit">Penerbit:</label>
                            <input type="text" class="form-control" id="penerbit" name="penerbit" required>
                        </div>
                        <div class="form-group">
                            <label for="jumlah">Jumlah:</label>
                            <input type="text" class="form-control" id="jumlah" name="jumlah" required>
                        </div>
                        <div class="form-group">
                            <label for="foto_sampul">Sampul Buku:</label>
                            <input type="file" class="form-control-file" id="foto_sampul" name="foto_sampul" accept="image/*">
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "footer.html"; ?>
