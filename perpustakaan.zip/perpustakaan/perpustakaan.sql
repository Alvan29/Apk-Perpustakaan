# SQL-Front 5.1  (Build 4.16)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: 127.0.0.1    Database: perpustakaan
# ------------------------------------------------------
# Server version 5.5.5-10.1.38-MariaDB

DROP DATABASE IF EXISTS `perpustakaan`;
CREATE DATABASE `perpustakaan` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `perpustakaan`;

#
# Source for table admin
#

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `Id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table admin
#

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table buku
#

DROP TABLE IF EXISTS `buku`;
CREATE TABLE `buku` (
  `Id_buku` varchar(6) NOT NULL DEFAULT '',
  `isbn` varchar(30) DEFAULT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `id_penulis` int(11) DEFAULT NULL,
  `id_penerbit` int(11) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `tahun_terbit` varchar(4) DEFAULT NULL,
  `sinopsis` text,
  `jumlah` int(11) DEFAULT NULL,
  `foto_sampul` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id_buku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table buku
#

LOCK TABLES `buku` WRITE;
/*!40000 ALTER TABLE `buku` DISABLE KEYS */;
/*!40000 ALTER TABLE `buku` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table detail_peminjaman
#

DROP TABLE IF EXISTS `detail_peminjaman`;
CREATE TABLE `detail_peminjaman` (
  `Id_peminjaman` varchar(6) NOT NULL DEFAULT '',
  `id_buku` varchar(6) DEFAULT NULL,
  `jumlah_pinjam` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table detail_peminjaman
#

LOCK TABLES `detail_peminjaman` WRITE;
/*!40000 ALTER TABLE `detail_peminjaman` DISABLE KEYS */;
/*!40000 ALTER TABLE `detail_peminjaman` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table kategori
#

DROP TABLE IF EXISTS `kategori`;
CREATE TABLE `kategori` (
  `Id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table kategori
#

LOCK TABLES `kategori` WRITE;
/*!40000 ALTER TABLE `kategori` DISABLE KEYS */;
/*!40000 ALTER TABLE `kategori` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table peminjaman
#

DROP TABLE IF EXISTS `peminjaman`;
CREATE TABLE `peminjaman` (
  `Id_peminjaman` varchar(6) NOT NULL DEFAULT '',
  `nis` varchar(6) DEFAULT NULL,
  `tanggal_pinjam` date DEFAULT NULL,
  `tanggal_pengembalian` date DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `status_pinjam` enum('Pinjam',' Kembali') DEFAULT NULL,
  PRIMARY KEY (`Id_peminjaman`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table peminjaman
#

LOCK TABLES `peminjaman` WRITE;
/*!40000 ALTER TABLE `peminjaman` DISABLE KEYS */;
/*!40000 ALTER TABLE `peminjaman` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table penerbit
#

DROP TABLE IF EXISTS `penerbit`;
CREATE TABLE `penerbit` (
  `Id_penerbit` int(11) NOT NULL AUTO_INCREMENT,
  `nama_penerbit` varchar(50) DEFAULT NULL,
  `kota` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Id_penerbit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table penerbit
#

LOCK TABLES `penerbit` WRITE;
/*!40000 ALTER TABLE `penerbit` DISABLE KEYS */;
/*!40000 ALTER TABLE `penerbit` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table pengadaan
#

DROP TABLE IF EXISTS `pengadaan`;
CREATE TABLE `pengadaan` (
  `Id_pengadaan` varchar(6) NOT NULL DEFAULT '',
  `tanggal_pengadaan` date DEFAULT NULL,
  `id_buku` varchar(6) DEFAULT NULL,
  `asal_buku` varchar(100) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id_pengadaan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table pengadaan
#

LOCK TABLES `pengadaan` WRITE;
/*!40000 ALTER TABLE `pengadaan` DISABLE KEYS */;
/*!40000 ALTER TABLE `pengadaan` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table pengembalian
#

DROP TABLE IF EXISTS `pengembalian`;
CREATE TABLE `pengembalian` (
  `Id_kembali` varchar(6) NOT NULL DEFAULT '',
  `id_pinjam` varchar(6) DEFAULT NULL,
  `tanggal_kembali` date DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `denda` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id_kembali`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table pengembalian
#

LOCK TABLES `pengembalian` WRITE;
/*!40000 ALTER TABLE `pengembalian` DISABLE KEYS */;
/*!40000 ALTER TABLE `pengembalian` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table penulis
#

DROP TABLE IF EXISTS `penulis`;
CREATE TABLE `penulis` (
  `Id-penulis` int(11) NOT NULL AUTO_INCREMENT,
  `nama_penulis` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id-penulis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table penulis
#

LOCK TABLES `penulis` WRITE;
/*!40000 ALTER TABLE `penulis` DISABLE KEYS */;
/*!40000 ALTER TABLE `penulis` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table siswa
#

DROP TABLE IF EXISTS `siswa`;
CREATE TABLE `siswa` (
  `nis` varchar(6) NOT NULL DEFAULT '',
  `nama_siswa` varchar(100) DEFAULT NULL,
  `jenis_kelamin` char(1) DEFAULT NULL,
  `tempat_lahir` varchar(30) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `no_hp` varchar(13) DEFAULT NULL,
  `foto_siswa` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`nis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table siswa
#

LOCK TABLES `siswa` WRITE;
/*!40000 ALTER TABLE `siswa` DISABLE KEYS */;
/*!40000 ALTER TABLE `siswa` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table temp_peminjaman
#

DROP TABLE IF EXISTS `temp_peminjaman`;
CREATE TABLE `temp_peminjaman` (
  `Id_temp` int(11) NOT NULL AUTO_INCREMENT,
  `id_buku` varchar(6) DEFAULT NULL,
  `jumlah_pinjam` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id_temp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table temp_peminjaman
#

LOCK TABLES `temp_peminjaman` WRITE;
/*!40000 ALTER TABLE `temp_peminjaman` DISABLE KEYS */;
/*!40000 ALTER TABLE `temp_peminjaman` ENABLE KEYS */;
UNLOCK TABLES;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
