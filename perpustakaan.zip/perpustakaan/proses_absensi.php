<?php
include "koneksi.php";

if(isset($_POST['nis'])) {
    $nis = $_POST['nis'];
    
    // Query untuk mencari data siswa berdasarkan NIS
    $query_siswa = mysqli_query($koneksi, "SELECT * FROM siswa WHERE nis = '$nis'");
    $siswa = mysqli_fetch_assoc($query_siswa);
    
    if($siswa) {
        // Jika siswa ditemukan, ambil kelas siswa
        $kelas = $siswa['kelas'];
        
        // Ambil tanggal absen
        $tanggal_absen = date('Y-m-d');
        
        // Query untuk memasukkan data absensi ke dalam tabel absen
        $insert = mysqli_query($koneksi, "INSERT INTO absen (nis, tanggal_absen, kelas) VALUES ('$nis', '$tanggal_absen', '$kelas')");
        
        if($insert) {
            // Jika absensi berhasil dicatat
            $response = array(
                'success' => true,
                'siswa' => $siswa
            );
            echo json_encode($response);
        } else {
            // Jika terjadi kesalahan saat mencatat absensi
            $response = array(
                'success' => false,
                'message' => 'Gagal mencatat absensi, silakan coba lagi.'
            );
            echo json_encode($response);
        }
    } else {
        // Jika siswa dengan NIS yang dimasukkan tidak ditemukan
        $response = array(
            'success' => false,
            'message' => 'Siswa dengan NIS ' . $nis . ' tidak ditemukan.'
        );
        echo json_encode($response);
    }
} else {
    // Jika NIS tidak dikirimkan melalui form
    $response = array(
        'success' => false,
        'message' => 'NIS tidak ditemukan.'
    );
    echo json_encode($response);
}
?>
