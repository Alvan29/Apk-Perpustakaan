<?php
include "koneksi.php";

// Proses formulir tambah jika formulir dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari formulir
    $Id_buku = $_POST['Id_buku'];
    $judul = $_POST['judul'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $nama_penulis = $_POST['nama_penulis'];
    $penerbit = $_POST['penerbit'];
    $jumlah = $_POST['jumlah'];
    $Id_kategori = $_POST['Id_kategori'];

    // Upload foto buku
    $foto_sampul = $_FILES['foto_sampul']['name'];
    $temp_file = $_FILES['foto_sampul']['tmp_name'];
    $folder_upload = "uploads/";

    // Cek apakah file yang diunggah adalah gambar
    $allowed_extensions = array("jpg", "jpeg", "png", "gif");
    $file_extension = strtolower(pathinfo($foto_sampul, PATHINFO_EXTENSION));

    if (!in_array($file_extension, $allowed_extensions)) {
        die("Maaf, hanya format JPG, JPEG, PNG, dan GIF yang diperbolehkan.");
    }

    // Pindahkan file yang diunggah ke folder uploads
    $uploaded_file = $folder_upload . $foto_sampul;

    if (move_uploaded_file($temp_file, $uploaded_file)) {
        // Query untuk menyimpan data siswa ke database
        $query = mysqli_query($koneksi, "INSERT INTO buku (Id_buku, judul, tahun_terbit, jumlah, foto_sampul, penerbit, nama_penulis, Id_kategori) VALUES ('$Id_buku', '$judul', '$tahun_terbit', '$jumlah', '$foto_sampul', '$penerbit', '$nama_penulis', '$Id_kategori')");

        if ($query) {
            // Jika berhasil disimpan, redirect ke halaman data siswa
            header('Location: data_buku.php');
            exit;
        } else {
            // Jika gagal disimpan, tampilkan pesan kesalahan
            die("Error: " . mysqli_error($koneksi));
        }
    } else {
        // Jika gagal mengunggah file, tampilkan pesan kesalahan
        die("Maaf, file sudah ada.");
    }
} else {
    // Jika tidak ada data yang dikirimkan melalui formulir, redirect ke halaman data siswa
    header('Location: data_buku.php');
    exit;
}
?>
