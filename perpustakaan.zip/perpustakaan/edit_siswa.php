<?php
include "koneksi.php";

// Periksa apakah parameter NIS telah diberikan
if (!isset($_GET['NIS'])) {
    header('Location: data_siswa.php');
    exit;
}

$nis = $_GET['NIS'];

// Query untuk mendapatkan data siswa berdasarkan NIS
$query = mysqli_query($koneksi, "SELECT * FROM siswa WHERE NIS = '$nis'");
$siswa = mysqli_fetch_assoc($query);

// Periksa apakah siswa dengan NIS yang diberikan ditemukan
if (!$siswa) {
    header('Location: data_siswa.php');
    exit;
}

// Proses formulir edit jika formulir dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari formulir
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];

    // Update data siswa dalam database
    $update_query = mysqli_query($koneksi, "UPDATE siswa SET Nama_Siswa = '$nama_siswa', Jenis_Kelamin = '$jenis_kelamin', Tempat_Lahir = '$tempat_lahir', Tanggal_Lahir = '$tanggal_lahir', Alamat = '$alamat', No_Telepon = '$no_telepon', kelas = '$kelas' WHERE NIS = '$nis'");

    if ($update_query) {
        // Redirect kembali ke halaman data siswa setelah berhasil mengedit
        header('Location: data_siswa.php');
        exit;
    } else {
        // Tampilkan pesan kesalahan jika gagal mengedit
        $error_message = "Gagal mengedit siswa.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Siswa</title>
    <!-- Tautan ke CSS atau Bootstrap jika digunakan -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Bagian header (jika ada) -->
    <?php include "header.html"; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Edit Siswa</div>
                    <div class="card-body">
                        <!-- Formulir Edit Siswa -->
                        <form method="POST" action="">
                            <!-- Input nilai-nilai siswa yang bisa diedit -->
                            <div class="form-group">
                                <label for="nama_siswa">Nama Siswa:</label>
                                <input type="text" class="form-control" name="nama_siswa" value="<?php echo $siswa['nama_siswa']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="kelas">Kelas:</label>
                                <input type="text" class="form-control" name="kelas" value="<?php echo $siswa['kelas']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin:</label>
                                <select class="form-control" name="jenis_kelamin" required>
                                    <option value="Laki-laki" <?php echo ($siswa['jenis_kelamin'] == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
                                    <option value="Perempuan" <?php echo ($siswa['jenis_kelamin'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="tempat_lahir">Tempat Lahir:</label>
                                <input type="text" class="form-control" name="tempat_lahir" value="<?php echo $siswa['tempat_lahir']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="tanggal_lahir">Tanggal Lahir:</label>
                                <input type="date" class="form-control" name="tanggal_lahir" value="<?php echo $siswa['tanggal_lahir']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="alamat">Alamat:</label>
                                <textarea class="form-control" name="alamat" required><?php echo $siswa['alamat']; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="no_telepon">No. Telepon:</label>
                                <input type="text" class="form-control" name="no_telepon" value="<?php echo $siswa['no_telepon']; ?>" required>
                            </div>

                            <!-- Tombol untuk mengirim formulir -->
                            <input type="submit" class="btn btn-primary" name="edit_siswa" value="Simpan Perubahan">
                        </form>

                        <!-- Tampilkan pesan kesalahan jika ada -->
                        <?php if (isset($error_message)) : ?>
                            <p style="color: red;"><?php echo $error_message; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bagian footer (jika ada) -->
    <?php include "footer.html"; ?>
</body>
</html>
