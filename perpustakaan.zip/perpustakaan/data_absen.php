<?php include "proteksi.php"; // Sertakan file proteksi.php untuk memeriksa sesi login

// Proses pencarian absen berdasarkan tanggal
$query = "SELECT absen.*, siswa.nama_siswa FROM absen JOIN siswa ON absen.nis = siswa.nis";
$tanggal = isset($_GET['tanggal_absen']) ? $_GET['tanggal_absen'] : date('Y-m-d');
if (!empty($tanggal)) {
    $query .= " WHERE absen.tanggal_absen = '$tanggal'";
}
$query .= " ORDER BY absen.kelas, siswa.nama_siswa"; // Urutkan berdasarkan kelas dan nama siswa
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Data Absen Siswa</title>

<!-- Tautan ke library JavaScript jika diperlukan -->
<script>
    function filterByDate() {
        var tanggal = document.getElementById('tanggal_absen').value;
        window.location.href = 'data_absen.php?tanggal_absen=' + tanggal;
    }
</script>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-lg-12 mt-2" style="min-height: 800px;">
            <div class="card">
                <div class="card-header">Data Absensi</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <!-- Form untuk memfilter berdasarkan tanggal -->
                                <div class="form-group">
                                    <label for="tanggal_absen">Pilih Tanggal:</label>
                                    <input type="date" id="tanggal_absen" name="tanggal_absen" value="<?= $tanggal ?>">
                                    <button onclick="filterByDate()">Filter</button>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col">
                                <table class="table table-bordered table-striped">
                                    <tr>
                                    <th>No</th>
                                    <th>NIS</th>
                                    <th>Nama Siswa</th>
                                    <th>Kelas</th>
                                    <th>Tanggal Absen</th>
                                    </tr>
                                    <?php
                                    $no = 1;
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= $row['nis'] ?></td>
                                            <td><?= $row['nama_siswa'] ?></td>
                                            <td><?= $row['kelas'] ?></td>
                                            <td><?= $row['tanggal_absen'] ?></td>
                                            <!-- Tambahkan kolom lain sesuai kebutuhan -->
                                        </tr>
                                    <?php } ?>
                                </table>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<?php include "footer.html"; ?>

</body>
</html>
