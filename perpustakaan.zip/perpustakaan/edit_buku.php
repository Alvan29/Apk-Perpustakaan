<?php
include "koneksi.php";

// Periksa apakah parameter id_buku telah diberikan
if (!isset($_GET['id'])) {
    header('Location: data_buku.php');
    exit;
}

$id_buku = $_GET['id'];

// Query untuk mendapatkan data buku berdasarkan id
$query = mysqli_query($koneksi, "SELECT * FROM buku WHERE id_buku = '$id_buku'");
$buku = mysqli_fetch_assoc($query);

// Periksa apakah buku dengan id yang diberikan ditemukan
if (!$buku) {
    header('Location: data_buku.php');
    exit;
}

// Proses formulir edit jika formulir dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari formulir
    $judul = $_POST['judul'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $nama_penulis = $_POST['nama_penulis'];
    $penerbit = $_POST['penerbit'];
    $jumlah = $_POST['jumlah'];

    // Update data buku dalam database
    $update_query = mysqli_query($koneksi, "UPDATE buku SET judul = '$judul', tahun_terbit = '$tahun_terbit', penerbit = '$penerbit', jumlah = '$jumlah', nama_penulis = '$nama_penulis' WHERE id_buku = '$id_buku'");

    if ($update_query) {
        // Redirect kembali ke halaman data buku setelah berhasil mengedit
        header('Location: data_buku.php');
        exit;
    } else {
        // Tampilkan pesan kesalahan jika gagal mengedit
        $error_message = "Gagal mengedit buku.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <!-- Tautan ke CSS atau Bootstrap jika digunakan -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Bagian header (jika ada) -->
    <?php include "header.html"; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Edit Buku</div>
                    <div class="card-body">
                        <!-- Formulir Edit Buku -->
                        <form method="POST" action="">
                            <!-- Input nilai-nilai buku yang bisa diedit -->
                            <div class="form-group">
                                <label for="judul">Judul Buku:</label>
                                <input type="text" class="form-control" name="judul" value="<?php echo $buku['judul']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="tahun_terbit">Tahun Terbit:</label>
                                <input type="text" class="form-control" name="tahun_terbit" value="<?php echo $buku['tahun_terbit']; ?>" required>
                            </div>

                            <div class="form-group">Penulis:</label>
                                <input type="text" class="form-control" name="nama_penulis" value="<?php echo $buku['nama_penulis']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="penerbit">Penerbit:</label>
                                <input type="text" class="form-control" name="penerbit" value="<?php echo $buku['penerbit']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="jumlah">Jumlah:</label>
                                <input type="text" class="form-control" name="jumlah" value="<?php echo $buku['jumlah']; ?>" required>
                            </div>

                            <!-- Tombol untuk mengirim formulir -->
                            <input type="submit" class="btn btn-primary" name="edit_buku" value="Simpan Perubahan">
                        </form>

                        <!-- Tampilkan pesan kesalahan jika ada -->
                        <?php if (isset($error_message)) : ?>
                            <p style="color: red;"><?php echo $error_message; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bagian footer (jika ada) -->
    <?php include "footer.html"; ?>
</body>
</html>
