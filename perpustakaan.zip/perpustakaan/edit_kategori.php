<?php
include "koneksi.php";

// Periksa apakah parameter Id_kategori telah diberikan
if (!isset($_GET['id'])) {
    header('Location: data_kategori.php');
    exit;
}

$id_kategori = $_GET['id'];

// Query untuk mendapatkan data kategori berdasarkan id
$query = mysqli_query($koneksi, "SELECT * FROM kategori WHERE Id_kategori = '$id_kategori'");
$kategori = mysqli_fetch_assoc($query);

// Periksa apakah kategori dengan id yang diberikan ditemukan
if (!$kategori) {
    header('Location: data_kategori.php');
    exit;
}

// Proses formulir edit jika formulir dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari formulir
    $nama_kategori = $_POST['nama_kategori'];

    // Update data kategori dalam database
    $update_query = mysqli_query($koneksi, "UPDATE kategori SET nama_kategori = '$nama_kategori' WHERE Id_kategori = '$id_kategori'");

    if ($update_query) {
        // Redirect kembali ke halaman data kategori setelah berhasil mengedit
        header('Location: data_kategori.php');
        exit;
    } else {
        // Tampilkan pesan kesalahan jika gagal mengedit
        $error_message = "Gagal mengedit kategori.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kategori</title>
    <!-- Tautan ke CSS atau Bootstrap jika digunakan -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Bagian header (jika ada) -->
    <?php include "header.html"; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Edit Kategori</div>
                    <div class="card-body">
                        <!-- Formulir Edit Kategori -->
                        <form method="POST" action="">
                            <!-- Input nilai-nilai kategori yang bisa diedit -->
                            <div class="form-group">
                                <label for="nama_kategori">Nama Kategori:</label>
                                <input type="text" class="form-control" name="nama_kategori" value="<?php echo $kategori['nama_kategori']; ?>" required>
                            </div>

                            <!-- Tombol untuk mengirim formulir -->
                            <input type="submit" class="btn btn-primary" name="edit_kategori" value="Simpan Perubahan">
                        </form>

                        <!-- Tampilkan pesan kesalahan jika ada -->
                        <?php if (isset($error_message)) : ?>
                            <p style="color: red;"><?php echo $error_message; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bagian footer (jika ada) -->
    <?php include "footer.html"; ?>
</body>
</html>
