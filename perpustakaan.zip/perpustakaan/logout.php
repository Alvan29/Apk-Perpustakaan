<?php
session_start();

// Hapus sesi admin
unset($_SESSION['admin_id']);

// Redirect ke halaman login
header("Location: index.php");
exit();
?>
