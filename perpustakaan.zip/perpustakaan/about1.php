<?php include "proteksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tim Kami</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        html, body{
            margin: 0;
            padding: 0;
            height: 100%
         } 
        #container {
            position:relative;
            min-height: 100%;
        }
        h2{
            margin: 10px, 0 , 0, 0;
            padding: 0;
        }
        h3{
            margin: 0;
            padding: 0;
            color: #68676767;
        }
        .card{
            margin: 10px;
            margin-left: 10px;
            width: 300px;
            height: 350px;
            perspective: 1000px;
            cursor: pointer;
        }
        .card img{
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
        }
        .card-container{
            width: 100%;
            height: 100%;
            transform-style: preserve-3d;
            transition: transform 0.5s;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            border-radius: 10px;
        }
        .card:hover .card-container{
            transform: rotateY(180deg);
        }
        .card-face{
            width: 100%;
            height: 100%;
            position: absolute;
            backface-visibility: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            gap: 10px;
            margin: 20px, 0 0 0;
            padding: 20px;
        }
        .front-face{
            transform: rotateY(0deg);
        }
        .back-face{
            transform: rotateY(180deg);
        }
        .row{
            margin: 10px 0 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            padding: 0 20px;
            font-size: 2rem;
        }
        .row i{
            color: #676868;
        }
        .ig:hover{
            color: #e1306c;
        }
        .git:hover{
            color: #000000;
        }
        .fb:hover:{
            color: #3b5998;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="card-container">
            <div class="card-face front-face">
                <!-- Bagian Depan -->
                <img src="img/a.jpg" alt="">
                <h2>M. Alvan A.G.</h2>
                <h3>Backend Developer</h3>
            </div>
            <div class="card-face back-face">
                <!-- Bagian Belakang -->
                <div class="container-about">
                    <h2>About Me:</h2>
                    <P>
                        "Selalu berusaha dan senantiasa berdo'a"
                    </P>
                    <div class="row">
                        <a href="https://wa.me/62959109742295" target="_blank"><i class="bi wa bi-whatsapp"></i></a>
                        <a href="https://www.instagram.com/alvan.5602?igsh=YzljYTk1ODg3Zg==" target="_blank"><i class="bi ig bi-instagram"></i></a>
                        <a href="https://github.com/Alvan29" target="_blank"><i class="bi git bi-github"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php include "footer.html";
?>