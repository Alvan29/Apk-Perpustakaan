<?php
include "koneksi.php";

// Periksa apakah parameter NIS telah diberikan
if (!isset($_GET['NIS'])) {
    header('Location: data_siswa.php');
    exit;
}

$nis = $_GET['NIS'];

// Query untuk mendapatkan data siswa berdasarkan NIS
$query = mysqli_query($koneksi, "SELECT * FROM siswa WHERE NIS = '$nis'");
$siswa = mysqli_fetch_assoc($query);

// Periksa apakah siswa dengan NIS yang diberikan ditemukan
if (!$siswa) {
    header('Location: data_siswa.php');
    exit;
}

// Proses penghapusan siswa jika dikonfirmasi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Hapus data siswa dari database
    $delete_query = mysqli_query($koneksi, "DELETE FROM siswa WHERE NIS = '$nis'");

    if ($delete_query) {
        // Redirect kembali ke halaman data siswa setelah berhasil menghapus
        header('Location: data_siswa.php');
        exit;
    } else {
        // Tampilkan pesan kesalahan jika gagal menghapus
        $error_message = "Gagal menghapus siswa.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Siswa</title>
    <!-- Tautan ke CSS atau Bootstrap jika digunakan -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Bagian header (jika ada) -->
    <?php include "header.html"; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2" style="min-height: 800px;">
                <div class="card">
                    <div class="card-header">Hapus Siswa</div>
                    <div class="card-body">
                        <!-- Konfirmasi Penghapusan Siswa -->
                        <p>Apakah Anda yakin ingin menghapus siswa dengan NIS "<?php echo $siswa['nis']; ?>" dan Nama "<?php echo $siswa['nama_siswa']; ?>"?</p>

                        <!-- Formulir Konfirmasi -->
                        <form method="POST" action="">
                            <!-- Tombol untuk mengkonfirmasi penghapusan -->
                            <input type="submit" class="btn btn-danger" name="hapus_siswa" value="Ya, Hapus">
                            <!-- Tautan untuk membatalkan penghapusan -->
                            <a href="data_siswa.php" class="btn btn-secondary">Batal</a>
                        </form>

                        <!-- Tampilkan pesan kesalahan jika ada -->
                        <?php if (isset($error_message)) : ?>
                            <p style="color: red;"><?php echo $error_message; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bagian footer (jika ada) -->
    <?php include "footer.html"; ?>
</body>
</html>
