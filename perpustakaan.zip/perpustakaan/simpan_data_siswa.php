<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil nilai dari formulir
    $nis = $_POST['nis'];
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];

    // Upload foto siswa
    $foto_siswa = $_FILES['foto_siswa']['name'];
    $temp_file = $_FILES['foto_siswa']['tmp_name'];
    $folder_upload = "uploads/";

    // Cek apakah file yang diunggah adalah gambar
    $allowed_extensions = array("jpg", "jpeg", "png", "gif");
    $file_extension = strtolower(pathinfo($foto_siswa, PATHINFO_EXTENSION));

    if (!in_array($file_extension, $allowed_extensions)) {
        die("Maaf, hanya format JPG, JPEG, PNG, dan GIF yang diperbolehkan.");
    }

    // Pindahkan file yang diunggah ke folder uploads
    $uploaded_file = $folder_upload . $foto_siswa;

    if (move_uploaded_file($temp_file, $uploaded_file)) {
        // Query untuk menyimpan data siswa ke database
        $query = mysqli_query($koneksi, "INSERT INTO siswa (NIS, Nama_Siswa, kelas, Jenis_Kelamin, Tempat_Lahir, Tanggal_Lahir, Alamat, No_Telepon, Foto_Siswa) VALUES ('$nis', '$nama_siswa', '$kelas', '$jenis_kelamin', '$tempat_lahir', '$tanggal_lahir', '$alamat', '$no_telepon', '$foto_siswa')");

        if ($query) {
            // Jika berhasil disimpan, redirect ke halaman data siswa
            header('Location: data_siswa.php');
            exit;
        } else {
            // Jika gagal disimpan, tampilkan pesan kesalahan
            die("Error: " . mysqli_error($koneksi));
        }
    } else {
        // Jika gagal mengunggah file, tampilkan pesan kesalahan
        die("Maaf, file sudah ada.");
    }
} else {
    // Jika tidak ada data yang dikirimkan melalui formulir, redirect ke halaman data siswa
    header('Location: data_siswa.php');
    exit;
}
?>
