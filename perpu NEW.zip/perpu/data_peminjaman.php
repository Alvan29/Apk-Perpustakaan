<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style/1.css">
  <link rel="stylesheet" href="style/2.css">
  <link rel="stylesheet" href="style/3.css">
  <link rel="stylesheet" href="style/load.css">
  

  <!--<link rel="stylesheet" href="style/foot.css">-->
  <link rel="icon" type="image/x-icon" href="image/Man2pacet-removebg-preview.png">
  <style>
    html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif;}
    .w3-sidebar {
      z-index: 3;
      width: 250px;
      top: 43px;
      bottom: 0;
      height: inherit;
    }
    .card-header{
        position: relative;
        top: 90px;
        margin-left: 250px;
        margin-bottom: 10px;
        font-size: 50px;
        border: 2px solid rgb(72, 70, 70);
        border-radius: 12px;
        padding: 5px;
        background-color: grey;
    }
    table {
            position: relative;
            margin-left: 250px;
            top:100px;
            border-collapse:inherit;
            width: 80%;
            border-radius: 12px;
            padding: 5px;
        }
 
        table, th, td {
            border: 1px solid rgb(0, 0, 0);
        }
        th, td {
            padding: 10px;
        }
        th {
            background-color: rgb(0, 0, 0);
            color: white;
        }
        tr:hover {background-color: #f5f5f5;}
        .form-group{
            position: relative;
            margin-left: 250px;
            margin-top: 25px;
            top: 90px;
            border-collapse:inherit;
            width: 10%;
            border: 1px solid grey;
            background-color: lightgrey;
            color: rgb(0, 0, 0);
            border-radius: 12px;
        }
        .button3,.button2{
            margin: 0px;
            position: relative;
            left:250px ;
            top: 100px;
            border-radius: 12px;
            width: 250px;
            font-size: 20px;
            border: 2px solid rgb(0, 0, 0);
            border-radius: 12px;
            padding: 5px;
        }
        .button3{
            margin: 5px;
            position: relative;
            left:250px ;
            top: 100px;
            border-radius: 12px;
            width: 50px;
            font-size: 20px;
            border: 2px solid rgb(0, 0, 0);
            border-radius: 12px;
            padding: 5px;}

        .button1{
        margin: 0px;
            position: relative;
            left:250px ;
            top: 100px;
            border-radius: 12px;
            width: 250px;
            font-size: 20px;
            border: 2px solid rgb(0, 0, 0);
            border-radius: 12px;
            padding: 5px;
            background-color: grey;
          }
          .button1,.button3 ::after{
            background-color: lightblue;
          }
        .container{
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: large;

        }
        label{
            position: relative;

        }
        #tanggal_absen{
            border-radius: 12px;

        }
        .btn-warning {
            border: 2px solid black;
            color: black;
            background-color: yellow;
            border-radius: 12px;
            padding: 5px;
            margin: 10px;
            position: relative;
            bottom: 5px;
        }
        .btn-danger {
            border: 2px solid black;
            color: black;
            background-color: red;
            border-radius: 12px;
            padding: 5px;
            margin: 5px;
            position: relative;
            top: 5px;
        }
        input{
          width: 30%;
          border-radius: 12px;
        }
        #btn-ok{
          border: 2px solid black;
            color: black;
            background-color: lightblue;
            border-radius: 12px;
            padding: 5px;
            margin: 5px;
            position: relative;
            top: 5px;
            width: 50%;
            left: 250px;
        }
        .btn-primary{
          border: 2px solid black;
            color: black;
            background-color: red;
            border-radius: 12px;
            padding: 5px;
            margin: 5px;
            position: relative;
            left: -190px;
            top: 90px;
        }
        .form-control{
          width: 20%;
          border-radius: 10px;
          position: relative;
            margin-left: 250px;
            margin-top: 25px;
            top: 90px;
            border-collapse:inherit;
            border: 1px solid grey;
            background-color: lightgrey;
            color: rgb(0, 0, 0);
            border-radius: 12px;
        }
        .ml-3{
            position: relative;
            right: 200px;
        }
        .btn-success{
          border: 2px solid black;
            color: black;
            background-color: lawngreen;
            border-radius: 12px;
            padding: 5px;
            margin: 5px;
            position: relative;
            top: 5px;
        }
    </style>
  <script src="javascript/main.js"></script>
  <script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 1000);
}

function showPage() {
   document.getElementById("loader").style.display = "none";
   document.getElementById("myDiv").style.display = "block";
}
  </script>
  <title>Data Peminjaman</title>
</head>
<body>
  <!-- INI GAMBAR LOADING JIKA MAU DI EDIT SILAHKAN SAYA MENYERAH BUAT LOADING SCREEN NYA YAAA :))))))
<div id="loader"></div> -->
<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-theme w3-top w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-right w3-hide-large w3-hover-white w3-large w3-theme-l1" href="javascript:void(0)" onclick="w3_open()"><i class="fa fa-bars"></i></a>
    <a href="1.php" class="w3-bar-item w3-button w3-theme-l1"><img class="logo" src="image/Man2pacet-removebg-preview.png" alt="icon"></a>
    <a href="1.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Home</a>
    <a href="tambah_admin.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Admin</a>
    <a href="pilih-1.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Log Out</a>
    <a href="tim.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Contact</a>
    <a href="https://man2cianjur.sch.id/" class="w3-bar-item w3-button w3-hide-small w3-hide-medium w3-hover-white">ABOUT OUR SCHOOL</a>
  </div>
</div>

<!-- Sidebar -->
<nav class="w3-sidebar w3-bar-block w3-collapse w3-large w3-theme-l5 w3-animate-left" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-right w3-xlarge w3-padding-large w3-hover-black w3-hide-large" title="Close Menu">
    <i class="fa fa-remove"></i>
  </a>
  <h4 class="w3-bar-item"><b>Menu</b></h4>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_absen.php">Absen</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_buku.php">Data Buku</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_kategori.php">Kategori</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_siswa.php">Data Siswa</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="peminjaman.php">Peminjaman Buku</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_peminjaman.php">Data Peminjaman</a>
</nav>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
  </div>
  <script>
    function filterByDate() {
        var tanggal = document.getElementById('tanggal_absen').value;
        window.location.href = 'data_absen.php?tanggal_absen=' + tanggal;
    }
</script> 
<!-- #region -->
<div class="container">
    <div class="row">
        <div class="col-lg-12 mt-2" style="min-height: 800px;">
            <div class="card">
                <div class="card-header">Daftar Peminjaman</div>
                <div class="card-body">
                    <div class="row mt-3">
                        <div class="col">
                            <form method="GET" action="data_peminjaman.php" class="form-inline">
                                <input type="date" name="tgl_mulai" class="form-control mr-3">
                                <input type="date" name="tgl_selesai" class="form-control ml-3">
                                <button type="submit" class="btn btn-primary ml-3" value="cari">Cek</button>
                            </form>
                        </div>
                        <div class="col mt-3">
                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th>No</th>
                                    <th>ID Peminjaman</th>
                                    <th>NIS</th>
                                    <th>Nama</th>
                                    <th>Kelas</th>
                                    <th>Judul Buku</th>
                                    <th>Tanggal Pinjam</th>
                                    <th>Batas Pinjam</th>
                                    <th>Jumlah Buku</th>
                                    <th>Status Pinjam</th>
                                    <th>Aksi</th>
                                </tr>
                                <?php
                                $tgl_mulai = isset($_GET['tgl_mulai']) ? $_GET['tgl_mulai'] : '';
                                $tgl_selesai = isset($_GET['tgl_selesai']) ? $_GET['tgl_selesai'] : '';

                                $where_clause = "";
                                if (!empty($tgl_mulai) && !empty($tgl_selesai)) {
                                    // Jika rentang waktu dimasukkan
                                    $where_clause = "WHERE peminjaman.tanggal_pinjam BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
                                }

                                $query_peminjaman = mysqli_query($koneksi, "SELECT peminjaman.Id_peminjaman, siswa.nis, siswa.nama_siswa AS siswa_nama, siswa.kelas, buku.judul, peminjaman.tanggal_pinjam, peminjaman.batas_pinjam, peminjaman.jumlah_pinjam, peminjaman.status_pinjam FROM peminjaman JOIN siswa ON peminjaman.nis = siswa.nis JOIN buku ON peminjaman.Id_buku = buku.Id_buku $where_clause");

                                $num_rows = mysqli_num_rows($query_peminjaman);
                                if ($num_rows < 1) {
                                    // Tidak ada data, tampilkan pesan
                                    echo '<div class="col mt-3">Tidak ada data</div>';
                                } else {
                                    $no = 1;
                                    while ($data_peminjaman = mysqli_fetch_assoc($query_peminjaman)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $data_peminjaman['Id_peminjaman']; ?></td>
                                            <td><?php echo $data_peminjaman['nis']; ?></td>
                                            <td><?php echo $data_peminjaman['siswa_nama']; ?></td>
                                            <td><?php echo $data_peminjaman['kelas']; ?></td>
                                            <td><?php echo $data_peminjaman['judul']; ?></td>
                                            <td><?php echo $data_peminjaman['tanggal_pinjam']; ?></td>
                                            <td><?php echo $data_peminjaman['batas_pinjam']; ?></td>
                                            <td><?php echo $data_peminjaman['jumlah_pinjam']; ?></td>
                                            <td><?php echo $data_peminjaman['status_pinjam']; ?></td>
                                            <td>
                                            <a href="selesai_peminjaman.php?Id_peminjaman=' . $data_peminjaman['Id_peminjaman'] . '"class="btn btn-success">Selesai</a>
                                                <?php
                                                if ($data_peminjaman['status_pinjam'] == 'Pinjam') {
                                                    echo '<a href="selesai_peminjaman.php?Id_peminjaman=' . $data_peminjaman['Id_peminjaman'] . '"class="btn btn-success">Selesai</a>';
                                                } else {
                                                    echo 'Peminjaman Selesai';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                <?php
                                    }
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


  <script>
    // Get the Sidebar
    var mySidebar = document.getElementById("mySidebar");
    
    // Get the DIV with overlay effect
    var overlayBg = document.getElementById("myOverlay");
    
    // Toggle between showing and hiding the sidebar, and add overlay effect
    function w3_open() {
      if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
        overlayBg.style.display = "none";
      } else {
        mySidebar.style.display = 'block';
        overlayBg.style.display = "block";
      }
    }
    
    // Close the sidebar with the close button
    function w3_close() {
      mySidebar.style.display = "none";
      overlayBg.style.display = "none";
    }
    </script>
</body>
</html>
