<?php
$host = "localhost"; // Nama hostnya
$username = "root"; // Username
$password = ""; // Password (Isi jika menggunakan password)
$database = "perpustakaan"; // Nama databasenya
$connect = mysqli_connect($host, $username, $password, $database); // Koneksi ke MySQL
if (!$connect) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
echo "Koneksi berhasil";
?>