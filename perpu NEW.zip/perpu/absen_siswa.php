<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/x-icon" href="image/Man2pacet-removebg-preview.png">
    <link rel="stylesheet" href="style.css">
    <title>absen_siswa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .tata-tertib {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #f9f9f9;
        }
        .tata-tertib h3 {
            margin-top: 0;
            color: #333;
        }
        .tata-tertib ul {
            padding-left: 20px;
        }
        .tata-tertib li {
            margin-bottom: 8px;
        }
        .popup-card {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 300px;
        padding: 20px;
        background-color: white;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        z-index: 9999;
        }
        .popup-card .close {
        position: absolute;
        top: 5px;
        right: 10px;
        cursor: pointer;
        }
    </style>
</head>
<body>
    <div>
        <div class="container">
            <h2>Form Absensi</h2>
            <form id="absensiForm" method="POST" action="proses_absensi.php">
                <label for="nis">NIS:</label>
                <input type="text" id="nis" name="nis" placeholder="Masukkan NIS..." required>
                <input type="submit" value="Absen">
            </form>
            <div class="tata-tertib">
                <h3>Tata Tertib Perpustakaan</h3>
                <ul>
                    <li>Setiap siswa wajib mengabsen sebelum menggunakan fasilitas perpustakaan.</li>
                    <li>Setiap siswa diharapkan menjaga kebersihan dan kerapihan perpustakaan.</li>
                    <li>Dilarang membawa makanan dan minuman ke dalam perpustakaan.</li>
                    <li>Dll...</li>
                </ul>
            </div>
        </div>
    </div>

    </div>
        <!-- Popup untuk menampilkan informasi siswa -->
        <div id="popup" class="popup-card">
            <span class="close" onclick="hidePopup()">&times;</span>
            <div class="popup-content">
                <img id="siswaFoto" src="" alt="Foto Siswa" style="max-width: 100%;">
                <p id="siswaNama"></p>
                <p id="siswaNis"></p>
                <p id="siswaKelas"></p>
                <p>Absen sudah tercatat!</p>
            </div>
        </div>
</body>
</html>