<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style/1.css">
  <link rel="stylesheet" href="style/2.css">
  <link rel="stylesheet" href="style/3.css">
  <link rel="stylesheet" href="style/load.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!--<link rel="stylesheet" href="style/foot.css">-->
  <link rel="icon" type="image/x-icon" href="image/Man2pacet-removebg-preview.png">
  <style>
    html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif;}
    .w3-sidebar {
      z-index: 3;
      width: 250px;
      top: 43px;
      bottom: 0;
      height: inherit;
    }
    .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
            position: relative;
            left: 500px;
            bottom: -80px;

        }

        .form-container h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .form-container form {
            display: flex;
            flex-direction: column;
        }

        .form-container label {
            margin-bottom: 8px;
            color: #555;
            font-weight: bold;
        }

        .form-container input {
            padding: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-container button {
            padding: 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #218838;
        }

        .back-link {
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
  <script src="javascript/main.js"></script>
  <script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 1000);
}

function showPage() {
   document.getElementById("loader").style.display = "none";
   document.getElementById("myDiv").style.display = "block";
}
  </script>
  <title>Tambah admin</title>
</head>
<body>
<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-theme w3-top w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-right w3-hide-large w3-hover-white w3-large w3-theme-l1" href="javascript:void(0)" onclick="w3_open()"><i class="fa fa-bars"></i></a>
    <a href="1.php" class="w3-bar-item w3-button w3-theme-l1"><img class="logo" src="image/Man2pacet-removebg-preview.png" alt="icon"></a>
    <a href="1.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Home</a>
    <a href="tambah_admin.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Admin</a>
    <a href="pilih-1.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Log Out</a>
    <a href="tim.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Contact</a>
    <a href="https://man2cianjur.sch.id/" class="w3-bar-item w3-button w3-hide-small w3-hide-medium w3-hover-white">ABOUT OUR SCHOOL</a>
  </div>
</div>

<!-- Sidebar -->
<nav class="w3-sidebar w3-bar-block w3-collapse w3-large w3-theme-l5 w3-animate-left" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-right w3-xlarge w3-padding-large w3-hover-black w3-hide-large" title="Close Menu">
    <i class="fa fa-remove"></i>
  </a>
  <h4 class="w3-bar-item"><b>Menu</b></h4>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_absen.php">Absen</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_buku.php">Data Buku</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_kategori.php">Kategori</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_siswa.php">Data Siswa</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="peminjaman.php">Peminjaman Buku</a>
  <a class="w3-bar-item w3-button w3-hover-black" href="data_peminjaman.php">Data Peminjaman</a>
</nav>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
  </div>
  <div class="form-container">
    <h2>Tambah Admin</h2>

    <?php
    // Tampilkan pesan sukses jika admin berhasil ditambahkan
    if (isset($success_message)) {
        echo "<p style='color: green;'>$success_message</p>";
    }

    // Tampilkan pesan error jika terjadi kesalahan
    if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
    }
    ?>

    <form method="post" action="">
        <!-- id_admin tidak perlu dimasukkan secara manual, karena diatur sebagai AUTO_INCREMENT -->
        <label for="username">Username:</label>
        <input type="text" name="username" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <button type="submit">Tambah Admin</button>
    </form>

    <a href="1.html" class="back-link">Kembali ke Dashboard</a>
</div>

  <script>
    // Get the Sidebar
    var mySidebar = document.getElementById("mySidebar");
    
    // Get the DIV with overlay effect
    var overlayBg = document.getElementById("myOverlay");
    
    // Toggle between showing and hiding the sidebar, and add overlay effect
    function w3_open() {
      if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
        overlayBg.style.display = "none";
      } else {
        mySidebar.style.display = 'block';
        overlayBg.style.display = "block";
      }
    }
    
    // Close the sidebar with the close button
    function w3_close() {
      mySidebar.style.display = "none";
      overlayBg.style.display = "none";
    }
    </script>
</body>
</html>